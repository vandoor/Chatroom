#include "loadstyle.h"

LoadStyle::LoadStyle()
{

}
