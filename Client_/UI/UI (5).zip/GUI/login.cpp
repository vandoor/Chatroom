#include "login.h"

Login::Login(QWidget *parent) : QWidget(parent)
{

}
