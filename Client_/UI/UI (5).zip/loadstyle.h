#ifndef LOADSTYLE_H
#define LOADSTYLE_H

#include<QApplication>

class LoadStyle
{
public:
    LoadStyle();
};

#endif // LOADSTYLE_H
