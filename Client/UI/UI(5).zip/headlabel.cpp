#include "headlabel.h"

HeadLabel::HeadLabel(QWidget *parent, QString headPhotoPath)
    : QLabel(parent),headPicturePath(headPhotoPath)
{
}
HeadLabel::~HeadLabel()
{

}
