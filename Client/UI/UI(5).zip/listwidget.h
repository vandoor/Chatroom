#ifndef LISTWIDGET_H
#define LISTWIDGET_H
#include <QListWidget>

class ListWidget : public QListWidget
{
public:
    ListWidget();
};

#endif // LISTWIDGET_H
